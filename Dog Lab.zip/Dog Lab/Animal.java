abstract public class Animal {
    private int age;


    public Animal() {
        age = 0;

    }

    public void setAge(int a) {
        age = a;
    }

    public int getAge() {
        return age;
    }

    public abstract void  eat();
    //since every subclass needs to have the method it doesnt define the method on purpose



}
