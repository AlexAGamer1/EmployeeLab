// ****************************************************************
// Main.java
//
// A simple test class that creates a Dog and makes it speak.
//          
// ****************************************************************


import java.util.ArrayList;

public class Main
{
    public static void main(String[] args)
    {
    /*
	Dog dog = new Dog("Spike");
    Labrador lab = new Labrador("Chocolate", "Chocolate");
    Yorkshire yorkie = new Yorkshire("Yorkie", 3);
	System.out.println(dog.getName() + " says " + dog.bark());
    System.out.println(lab.getName() + " " + lab.bark());
    System.out.println(yorkie.getName() + " " + yorkie.bark());
    yorkie.waddle();
    //it doesnt work because the lab and yorkie classes are both subclasses of the same parent class  so they dont inherit anything from eachother
	lab.waddle();


    Dog[] dogs = new Dog[3];
    dogs[0] = dog;
    dogs[1] = lab;
    dogs[2] = yorkie;

    for (int i = 0; i < dogs.length; i++) {
        dogs[i].bark();
    }
    for (Dog i : dogs) {
        i.bark();
    }
    //you have to cast to a yorkie because there is no waddle method in the dog class which is what it looks for first
    //you dont have to cast the bark method becasue there already is one in the dog class
    ((Yorkshire)dogs[1]).waddle();
    ArrayList<Dog> dogArrayList = new ArrayList<Dog>();
    dogArrayList.add(dog);
    dogArrayList.add(lab);
    dogArrayList.add(yorkie);

    for (int i = 0; i < dogArrayList.size(); i++) {
        dogArrayList.get(i).bark();
    }
    for (Dog i : dogArrayList) {
        i.bark();
    }
    ((Yorkshire)dogArrayList.get(1)).waddle();
    */

    ArrayList<Animal> animals = new ArrayList<Animal>();
    Dog dog1 = new Dog("Dog1");
    Dog dog2 = new Labrador("Dog2", "Black");
    Dog dog3 = new Yorkshire("Dog3", 3);
    animals.add(dog1);
    animals.add(dog2);
    animals.add(dog3);
    for (Animal i : animals) {
        i.setAge(5);
    }

    for (Animal i : animals) {
        System.out.println(i.getAge());
        i.eat();
        //there is an error because it doesnt find a bark method in the animal class
        ((Dog)i).bark();
    }



    }
}
